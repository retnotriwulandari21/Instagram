<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("location:login.php?pesan=login");
}
include "koneksi.php";
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="01.jpeg">
    <title>RAINBOW</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="index.css">
    

    <style>
        .card-img-top {
            transition: transform 0.3s; 
        }
        .card-img-top:hover {
            transform: scale(1.1);
        }
    </style>
</head>
<body style="background-image: url('bgpink.jpg');">

<nav class="navbar navbar-expand-lg  fixed-top" data-bs-theme="danger" style="background-color: #FF4B91;" >
  <div class="container">
    <img src="01.png" alt="" width="100">
    <a class="navbar-brand fs-2 fw-bold me-5" href="#">RAINBOW</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
      </ul>
    </div>
    <ul class="navbar-nav me-2">
        <li class="nav-item">
        <button type="button" class="btn btn-danger bi bi-plus-square " data-bs-toggle="modal" data-bs-target="#exampleModal" style="font-size: 30px;"></button>
        </li>
      </ul>
      <ul class="navbar-nav">
      <li class="nav-item">
        <a href="logout.php"><button class="btn btn-danger"><i class="bi bi-box-arrow-right" style="font-size: 30px;"></i></button></a>
        </li>
      </ul>
  </div>
</nav><br><br><br>
<center>
    <div class="container"><br><br>

    <?php while($post = mysqli_fetch_assoc($query)) { ?>
    <div class="row">
    <div class="col mb-3 mb-sm-0">
    <div class="card border-dark mb-3" style="width: 23rem;">
    <img src="images/<?= $post['foto'] ?>" class="card-img-top" alt="" width="50" height="200">
    <p class="card-header fs-4 fw-semibold border-dark bg-white"><?= $post['caption'] ?></p>
    <div class="card-body">
        <p class="card-text"><?= $post['lokasi'] ?></p>
        <a href="hapus.php?no=<?= $post['no'] ?>" class="btn btn-danger"><i class="bi bi-trash-fill"></i></a>
        <a href="" type="button" class = "btn btn-warning" data-bs-toggle="modal" data-bs-target="#ModalEdit<?=$post['no']?>"><i class="bi bi-pencil-square"></i></a>
    </div>
    </div>
    </div>
    </div>
    <div class="modal fade" id="ModalEdit<?=$post['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 fw-bold" id="exampleModalLabel">EDIT</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?=$post['no']?>">
        <input type="hidden" name="foto_lama" value="<?=$post['foto']?>">

        <label for="" class="fw-bold">Foto</label>
        <input type="file" name="foto" class="form-control fw-bold" value="<?=$post['foto']?>"><br>
        <img src="images/<?= $post['foto'] ?>" width="80" alt="" class="mb-3"><br>

        <label for="" class="fw-bold">Caption</label>
        <input type="text" name="caption" class="form-control"autocomplete="off" value="<?=$post['caption']?>"><br>

        <label for="" class="fw-bold">Lokasi</label>
        <input type="text" name="lokasi" class="form-control"autocomplete="off" value="<?=$post['lokasi']?>"><br>
      </div>
      <div class="modal-footer">
      <input class="btn btn-danger" type="submit" value="Post" name="update">
        </div>
      </form>
    </div>
  </div>
</div>
  </div>
</div>
        <?php } ?>
        </div>
        </center>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 fw-bold" id="exampleModalLabel">TAMBAH</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="" class="fw-bold">Foto</label>
        <input type="file" name="foto" class="form-control fw-bold" required><br>

        <label for="" class="fw-bold">Caption</label>
        <input type="text" name="caption" class="form-control"autocomplete="off"><br>

        <label for="" class="fw-bold">Lokasi</label>
        <input type="text" name="lokasi" class="form-control"autocomplete="off"><br>
      </div>
      <div class="modal-footer">
      <input class="btn btn-success" type="submit" value="Post" name="simpan">
        </div>
      </form>
    </div>
  </div>
</div>
</body>
</html>
